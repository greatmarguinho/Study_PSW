from django.contrib import admin
from .models import Apostila, ViewApostila

admin.site.register(Apostila)
admin.site.register(ViewApostila)